# Flutter guide — Chat after quote accept

**Send this file to the Flutter co-dev.**  
Same Firebase project as the web shop dashboard.

Chat unlocks **only after** the builder accepts a shop quotation.  
Backend (rules + Cloud Functions) is deployed from the **web** repo — Flutter does **not** deploy them.

---

## 1. Flow (both apps)

```
Builder posts project          →  projectPosts/{postId}   (must include userId)
Shop submits quotation         →  projectPosts/{postId}/quotations/{quotationId}  status: pending
Builder taps Accept            →  update quotation status: accepted
Cloud Function runs            →  creates conversations/{postId}_{shopId} + FCM
Builder + Shop can chat        →  conversations/{id}/messages/{messageId}
```

---

## 2. Project post must have builder uid

When creating a project, always save the signed-in builder:

```dart
await FirebaseFirestore.instance.collection('projectPosts').add({
  'userId': FirebaseAuth.instance.currentUser!.uid, // REQUIRED for chat
  'projectName': title,
  'projectType': type,
  // ...other fields
  'postedAt': FieldValue.serverTimestamp(),
  'quotationCount': 0,
  'status': 'open',
});
```

Also acceptable instead of / in addition to `userId`: `builderId`, `ownerId`, or `postedBy`.

---

## 3. Accept a quotation (required)

```dart
Future<void> acceptQuotation({
  required String postId,
  required String quotationId,
}) async {
  final uid = FirebaseAuth.instance.currentUser?.uid;
  if (uid == null) throw Exception('Not signed in');

  await FirebaseFirestore.instance
      .collection('projectPosts')
      .doc(postId)
      .collection('quotations')
      .doc(quotationId)
      .update({
        'status': 'accepted',
        'acceptedAt': FieldValue.serverTimestamp(),
        'acceptedBy': uid,
        'updatedAt': FieldValue.serverTimestamp(),
      });
}

Future<void> rejectQuotation({
  required String postId,
  required String quotationId,
}) async {
  final uid = FirebaseAuth.instance.currentUser?.uid;
  if (uid == null) throw Exception('Not signed in');

  await FirebaseFirestore.instance
      .collection('projectPosts')
      .doc(postId)
      .collection('quotations')
      .doc(quotationId)
      .update({
        'status': 'rejected',
        'rejectedAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
}
```

After accept, wait for Cloud Function to create the conversation  
(or use the helper in section 5 as a fallback).

Conversation id is always:

```dart
String conversationId(String projectId, String shopId) => '${projectId}_$shopId';
```

`shopId` is on the quotation document: `quotation['shopId']`.

---

## 4. Firestore shapes

### Conversation — `conversations/{projectId}_{shopId}`

| Field | Type |
|--------|------|
| `projectId` | string |
| `quotationId` | string |
| `shopId` | string |
| `shopName` | string |
| `builderId` | string |
| `builderName` | string |
| `projectTitle` | string |
| `status` | `"open"` \| `"closed"` |
| `lastMessage` | string |
| `lastMessageAt` | Timestamp |
| `lastSenderId` | string |
| `createdAt` | Timestamp |
| `updatedAt` | Timestamp |

### Message — `conversations/{id}/messages/{messageId}`

| Field | Type |
|--------|------|
| `senderId` | string (auth uid) |
| `senderRole` | `"builder"` \| `"shop"` \| `"system"` |
| `text` | string (max 4000) |
| `createdAt` | Timestamp |

---

## 5. Ready Dart helpers (copy into Flutter)

```dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ChatService {
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  String conversationId(String projectId, String shopId) =>
      '${projectId}_$shopId';

  /// List my chats (builder side)
  Stream<QuerySnapshot<Map<String, dynamic>>> watchMyConversations() {
    final uid = _auth.currentUser!.uid;
    return _db
        .collection('conversations')
        .where('builderId', isEqualTo: uid)
        .orderBy('lastMessageAt', descending: true)
        .snapshots();
  }

  /// Live messages in one thread
  Stream<QuerySnapshot<Map<String, dynamic>>> watchMessages(String conversationId) {
    return _db
        .collection('conversations')
        .doc(conversationId)
        .collection('messages')
        .orderBy('createdAt')
        .limit(200)
        .snapshots();
  }

  /// Send as builder
  Future<void> sendMessage({
    required String conversationId,
    required String text,
  }) async {
    final uid = _auth.currentUser!.uid;
    final trimmed = text.trim();
    if (trimmed.isEmpty) return;

    final convRef = _db.collection('conversations').doc(conversationId);

    await convRef.collection('messages').add({
      'senderId': uid,
      'senderRole': 'builder',
      'text': trimmed.length > 4000 ? trimmed.substring(0, 4000) : trimmed,
      'createdAt': FieldValue.serverTimestamp(),
    });

    await convRef.update({
      'lastMessage':
          trimmed.length > 200 ? trimmed.substring(0, 200) : trimmed,
      'lastMessageAt': FieldValue.serverTimestamp(),
      'lastSenderId': uid,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  /// Fallback if Cloud Function has not created the thread yet
  Future<String> ensureConversationAfterAccept({
    required String projectId,
    required String shopId,
    required String quotationId,
    required String projectTitle,
    String shopName = '',
    String builderName = 'Builder',
  }) async {
    final uid = _auth.currentUser!.uid;
    final id = conversationId(projectId, shopId);
    final ref = _db.collection('conversations').doc(id);
    final snap = await ref.get();

    if (!snap.exists) {
      await ref.set({
        'projectId': projectId,
        'quotationId': quotationId,
        'shopId': shopId,
        'shopName': shopName,
        'builderId': uid,
        'builderName': builderName,
        'projectTitle': projectTitle,
        'status': 'open',
        'lastMessage': 'Quote accepted — you can now message each other.',
        'lastMessageAt': FieldValue.serverTimestamp(),
        'lastSenderId': '',
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
    return id;
  }
}
```

---

## 6. FCM data payloads (handle in Flutter)

| `data.type` | When | Open |
|-------------|------|------|
| `chat_unlocked` | Builder accepted → chat ready | Chat screen for `conversationId` |
| `chat_message` | New message from shop | Same |
| `new_quotation` | Shop submitted a bid (existing) | Project / quotes screen |

Example:

```dart
void handleFcmData(Map<String, dynamic> data) {
  final type = data['type'];
  final conversationId = data['conversationId'];

  if (type == 'chat_unlocked' || type == 'chat_message') {
    // Navigate to ChatScreen(conversationId: conversationId)
  }
}
```

---

## 7. UI checklist (Flutter)

- [ ] Accept / Reject buttons on pending quotations  
- [ ] After accept → navigate to chat (use `conversationId(postId, shopId)`)  
- [ ] Inbox: stream `watchMyConversations()`  
- [ ] Thread: stream `watchMessages(id)`  
- [ ] Composer: `sendMessage(...)` with `senderRole: 'builder'`  
- [ ] Hide chat until quote is `accepted`  
- [ ] Handle FCM `chat_unlocked` / `chat_message`

---

## 8. Indexes (if Firebase console asks)

Create composite indexes:

1. Collection `conversations`  
   - `builderId` Ascending  
   - `lastMessageAt` Descending  

2. Collection `conversations`  
   - `shopId` Ascending  
   - `lastMessageAt` Descending  

---

## 9. What web already did

- Shop **Messages** tab (Basic / Pro / Business)  
- **Message builder →** on accepted quotes  
- Firestore rules for accept + chat  
- Functions: `onQuotationAccepted`, `onChatMessageCreated`  

Web deploy (not Flutter):

```powershell
firebase deploy --only firestore:rules,functions:onQuotationAccepted,functions:onChatMessageCreated
```

---

## 10. Quick test

1. Web shop submits a quotation on a Flutter project  
2. Flutter builder accepts that quotation  
3. Both see a conversation and can send messages  
4. Push arrives on the other device when a message is sent  

If chat does not appear after accept: confirm `userId` is on the project post, then call `ensureConversationAfterAccept(...)`.
